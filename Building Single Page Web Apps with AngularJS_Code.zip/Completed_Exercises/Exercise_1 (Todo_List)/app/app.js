'use strict';

angular.module('todoApp', [
  'todoApp.controllers',
  'ngAnimate'
]);